package commands;

public class Luz {
    public void ligar() {
        System.out.println("A luz est� ligada.");
    }

    public void desligar() {
        System.out.println("A luz est� desligada.");
    }
}